# 🧠 Approach & Methodology

YOLOv8 is used to detect players in two views. We match detected players using the Hungarian algorithm.

## 🛠️ Techniques

- **Detection**: YOLOv8n (`yolov8n.pt`)
- **Features**: Bounding box, center point
- **Matching**: Hungarian algorithm

## ✅ Outcomes

- Players matched across views
- Output saved to `player_id_mapping.json`

## ⚠️ Challenges

- No fine-tuned custom model
- Inconsistent detection at times

## 🚧 Future Work

- Use visual embeddings for better matching
- Add pose/jersey-based re-identification
